package com.cognizant.springrest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "operational")
public class Operational {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "parameter")
	private String parameter;
	
	@Column(name = "jan")
	private String jan;

	@Column(name = "feb")
	private String feb;

	@Column(name = "mar")
	private String mar;

	@Column(name = "apr")
	private String apr;

	@Column(name = "may")
	private String may;

	@Column(name = "jun")
	private String jun;
	
	@Column(name = "jul")
	private String jul;
	
	@Column(name = "aug")
	private String aug;
	
	@Column(name = "sep")
	private String sep;
	
	@Column(name = "oct")
	private String oct;
	
	@Column(name = "nov")
	private String nov;
	
	@Column(name = "dec")
	private String dec;

	@Column(name = "total")
	private String total;

	
	public Operational() {
	}

	/**
	 * @param parameter
	 * @param jan
	 * @param feb
	 * @param mar
	 * @param apr
	 * @param may
	 * @param jun
	 * @param jul
	 * @param aug
	 * @param sep
	 * @param oct
	 * @param nov
	 * @param dec
	 */
	public Operational(String parameter, String jan, String feb, String mar, String apr, String may, String jun, String jul,
			String aug, String sep, String oct, String nov, String dec, String total) {
		this.parameter = parameter;
		this.jan = jan;
		this.feb = feb;
		this.mar = mar;
		this.apr = apr;
		this.may = may;
		this.jun = jun;
		this.jul = jul;
		this.aug = aug;
		this.sep = sep;
		this.oct = oct;
		this.nov = nov;
		this.dec = dec;
		this.total = total; 
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	public String getJan() {
		return jan;
	}

	public void setJan(String jan) {
		this.jan = jan;
	}

	public String getFeb() {
		return feb;
	}

	public void setFeb(String feb) {
		this.feb = feb;
	}

	public String getMar() {
		return mar;
	}

	public void setMar(String mar) {
		this.mar = mar;
	}

	public String getApr() {
		return apr;
	}

	public void setApr(String apr) {
		this.apr = apr;
	}

	public String getMay() {
		return may;
	}

	public void setMay(String may) {
		this.may = may;
	}

	public String getJun() {
		return jun;
	}

	public void setJun(String jun) {
		this.jun = jun;
	}

	public String getJul() {
		return jul;
	}

	public void setJul(String jul) {
		this.jul = jul;
	}

	public String getAug() {
		return aug;
	}

	public void setAug(String aug) {
		this.aug = aug;
	}

	public String getSep() {
		return sep;
	}

	public void setSep(String sep) {
		this.sep = sep;
	}

	public String getOct() {
		return oct;
	}

	public void setOct(String oct) {
		this.oct = oct;
	}

	public String getNov() {
		return nov;
	}

	public void setNov(String nov) {
		this.nov = nov;
	}

	public String getDec() {
		return dec;
	}

	public void setDec(String dec) {
		this.dec = dec;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "Operational [id=" + id + ", parameter=" + parameter + ", jan=" + jan + ", feb=" + feb + ", mar=" + mar
				+ ", apr=" + apr + ", may=" + may + ", jun=" + jun + ", jul=" + jul + ", aug=" + aug + ", sep=" + sep
				+ ", oct=" + oct + ", nov=" + nov + ", dec=" + dec + "]";
	}
	
	

}
