package com.cognizant.springrest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springrest.model.Summary;
import com.cognizant.springrest.repo.SummaryRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class SummaryController {

	@Autowired
	SummaryRepository repository;

	@GetMapping("/summary")
	public List<Summary> getSummary() {
		System.out.println("Get Summary...");

		List<Summary> summary = new ArrayList<>();
		repository.findAll().forEach(summary::add);

		return summary;
	}

	@PostMapping(value = "/summary/create")
	public Summary postSummary(@RequestBody Summary summary) {

		Summary _summary = repository.save(new Summary(summary.getCategory(), summary.getStatus()));
		return _summary;
	}

	@DeleteMapping("/summary/{id}")
	public ResponseEntity<String> deleteSummary(@PathVariable("id") long id) {
		System.out.println("Delete Summary with ID = " + id + "...");

		repository.deleteById(id);

		return new ResponseEntity<>("Summary has been deleted!", HttpStatus.OK);
	}

	@DeleteMapping("/summary/delete")
	public ResponseEntity<String> deleteAllSummary() {
		System.out.println("Delete All Summary...");

		repository.deleteAll();

		return new ResponseEntity<>("All Summary data have been deleted!", HttpStatus.OK);
	}
	
	@GetMapping(value = "summary/category/{category}")
	public List<Summary> findByCategory(@PathVariable String category) {

		List<Summary> summary = repository.findByCategory(category);
		return summary;
	}


	@PutMapping("/summary/{id}")
	public ResponseEntity<Summary> updateSummary(@PathVariable("id") long id, @RequestBody Summary summary) {
		System.out.println("Update Summary with ID = " + id + "...");

		Optional<Summary> summaryData = repository.findById(id);

		if (summaryData.isPresent()) {
			Summary _summary = summaryData.get();
			_summary.setCategory(summary.getCategory());
			_summary.setStatus(summary.getStatus());
			_summary.setActive(summary.isActive());
			return new ResponseEntity<>(repository.save(_summary), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
