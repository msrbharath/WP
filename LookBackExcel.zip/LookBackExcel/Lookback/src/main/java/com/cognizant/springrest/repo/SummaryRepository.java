package com.cognizant.springrest.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.springrest.model.Summary;

public interface SummaryRepository extends CrudRepository<Summary, Long> {
	List<Summary> findByCategory(String category);
}
