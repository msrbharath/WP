package com.cognizant.springrest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springrest.model.Operational;
import com.cognizant.springrest.repo.OperationalRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class OperationalController {

	@Autowired
	OperationalRepository repository;

	@GetMapping("/operational")
	public List<Operational> getOperational() {
		System.out.println("Get Operational...");

		List<Operational> operational = new ArrayList<>();
		repository.findAll().forEach(operational::add);

		return operational;
	}

	@PostMapping(value = "/operational/create")
	public Operational postOperational(@RequestBody Operational operational) {

		Operational _operational = repository.save(new Operational(operational.getParameter(), operational.getJan(), operational.getFeb(), 
				operational.getMar(), operational.getApr(), operational.getMay(), operational.getJun(), operational.getJul(), operational.getAug(),
				operational.getSep(), operational.getOct(), operational.getNov(), operational.getDec(), operational.getTotal()));
		return _operational;
	}

	@DeleteMapping("/operational/{id}")
	public ResponseEntity<String> deleteOperational(@PathVariable("id") long id) {
		System.out.println("Delete Opearational with ID = " + id + "...");

		repository.deleteById(id);

		return new ResponseEntity<>("Opearational has been deleted!", HttpStatus.OK);
	}

	@DeleteMapping("/opeartional/delete")
	public ResponseEntity<String> deleteAllOperational() {
		System.out.println("Delete All Operational...");

		repository.deleteAll();

		return new ResponseEntity<>("All Operational data have been deleted!", HttpStatus.OK);
	}
	
	@GetMapping(value = "operational/parameter/{parameter}")
	public List<Operational> findByParameter(@PathVariable String parameter) {

		List<Operational> operational = repository.findByParameter(parameter);
		return operational;
	}


	@PutMapping("/operational/{id}")
	public ResponseEntity<Operational> updateOperational(@PathVariable("id") long id, @RequestBody Operational operational) {
		System.out.println("Update Operational with ID = " + id + "...");

		Optional<Operational> operationalData = repository.findById(id);

		if (operationalData.isPresent()) {
			Operational _operational = operationalData.get();
			_operational.setParameter(operational.getParameter());
			_operational.setJan(operational.getJan());
			_operational.setFeb(operational.getFeb());
			_operational.setMar(operational.getMar());
			_operational.setApr(operational.getApr());
			_operational.setMay(operational.getMay());
			_operational.setJun(operational.getJun());
			_operational.setJul(operational.getJul());
			_operational.setAug(operational.getAug());
			_operational.setSep(operational.getSep());
			_operational.setOct(operational.getOct());
			_operational.setNov(operational.getNov());
			_operational.setDec(operational.getDec());
			return new ResponseEntity<>(repository.save(_operational), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
