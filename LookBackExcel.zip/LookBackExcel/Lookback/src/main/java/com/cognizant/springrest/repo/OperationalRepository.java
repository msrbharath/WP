package com.cognizant.springrest.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.springrest.model.Operational;

public interface OperationalRepository extends CrudRepository<Operational, Long> {
	List<Operational> findByParameter(String parameter);
}
