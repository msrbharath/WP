import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OperationalService {

  private baseUrl = 'http://localhost:8080/api/operational';

  constructor(private http: HttpClient) { }

  getOperational(id: number): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createOperational(operational: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/create`, operational);
  }

  updateOperational(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteOperational(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getOperationalList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  getOperationalByParameter(operational: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/operational/${operational}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(`${this.baseUrl}` + `/delete`, { responseType: 'text' });
  }
}
