import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SummaryComponent } from './summary/summary.component';
import { OperationalComponent } from './operational/operational.component';
import { DeliveryComponent } from './delivery/delivery.component';
import { ProjectsComponent } from './projects/projects.component';
import { ChangesComponent } from './changes/changes.component';
import { AwardsComponent } from './awards/awards.component';
import { CertificationComponent } from './certification/certification.component';
import { InnovationComponent } from './innovation/innovation.component';
import { MainspringComponent } from './mainspring/mainspring.component';
import { ProposalComponent } from './proposal/proposal.component';
import { ExcelComponent } from './excel/excel.component';

const routes: Routes = [
    { path: '', redirectTo: 'summary', pathMatch: 'full' },
    { path: 'summary', component: SummaryComponent },
    { path: 'operational', component: OperationalComponent },
    { path: 'delivery', component: DeliveryComponent },
    { path: 'projects', component: ProjectsComponent },
    { path: 'changes', component: ChangesComponent },
    { path: 'awards', component: AwardsComponent },
    { path: 'certification', component: CertificationComponent },
    { path: 'innovation', component: InnovationComponent },
    { path: 'mainspring', component: MainspringComponent },
    { path: 'proposal', component: ProposalComponent },
    { path: 'excelvalues', component: ExcelComponent },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }
