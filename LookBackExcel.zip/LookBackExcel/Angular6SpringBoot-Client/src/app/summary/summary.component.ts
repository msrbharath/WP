import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { PsdSummary } from '../psdsummary';
import { SummaryService } from '../summary.service';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {

  psdsummary: PsdSummary = new PsdSummary();
  submitted = false;
  editable = false;
  summaryList: Observable<PsdSummary[]>;;

  constructor(private summaryService: SummaryService) { 
    this.reloadData();
  }

  ngOnInit() {
    this.reloadData();
  }


  newSummary(): void {
    this.submitted = false;
    this.editable = true;
    this.psdsummary = new PsdSummary();
  }

  save() {
    this.summaryService.createSummary(this.psdsummary)
      .subscribe(data => console.log(data), error => console.log(error));
    this.reloadData();
    this.psdsummary = new PsdSummary();
  }

  deleteSummary(deleteId:number) {
    this.summaryService.deleteSummary(deleteId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  editSummary(updateId:number, summary:PsdSummary) {
    this.summaryService.updateSummary(updateId, summary)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }


  onSubmit() {
    this.editable = false;
    this.submitted = true;
    this.save();
  }

  reloadData() {
    this.summaryList = this.summaryService.getSummaryList();
  }

}
