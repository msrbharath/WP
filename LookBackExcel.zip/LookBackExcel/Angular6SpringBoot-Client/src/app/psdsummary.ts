export class PsdSummary {
    id: number;
    category: string;
    status: string;
    active: boolean;
}
