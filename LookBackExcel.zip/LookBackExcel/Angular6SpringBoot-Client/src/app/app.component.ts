import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PSD Lookback - 2018';
  description = 'Click on the below buttons to view the project metrics of the year 2018';
}
