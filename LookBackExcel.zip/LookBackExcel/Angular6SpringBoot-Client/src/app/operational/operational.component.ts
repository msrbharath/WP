import { Component, OnInit } from '@angular/core';
import { Operational } from '../operational';
import { Observable } from 'rxjs';
import { OperationalService } from '../operational.service';

@Component({
  selector: 'app-operational',
  templateUrl: './operational.component.html',
  styleUrls: ['./operational.component.css']
})
export class OperationalComponent implements OnInit {

  operational: Operational = new Operational();
  submitted = false;
  editable = false;
  operationalList: Observable<Operational[]>;;

  constructor(private operationalService: OperationalService) { 
    this.reloadData();
  }

  ngOnInit() {
    this.reloadData();
  }


  newOperational(): void {
    this.submitted = false;
    this.editable = true;
    this.operational = new Operational();
  }

  save() {
    this.operationalService.createOperational(this.operational)
      .subscribe(data => console.log(data), error => console.log(error));
    this.reloadData();
    this.operational = new Operational();
  }

  deleteOperational(deleteId:number) {
    this.operationalService.deleteOperational(deleteId)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  editOperational(updateId:number, operational:Operational) {
    this.operationalService.updateOperational(updateId, operational)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }


  onSubmit() {
    this.editable = false;
    this.submitted = true;
    this.save();
  }

  reloadData() {
    this.operationalList = this.operationalService.getOperationalList();
  }

}
