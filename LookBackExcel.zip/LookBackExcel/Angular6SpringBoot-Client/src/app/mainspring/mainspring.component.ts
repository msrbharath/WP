import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainspring',
  templateUrl: './mainspring.component.html',
  styleUrls: ['./mainspring.component.css']
})
export class MainspringComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
