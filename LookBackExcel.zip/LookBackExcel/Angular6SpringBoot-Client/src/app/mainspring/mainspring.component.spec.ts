import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainspringComponent } from './mainspring.component';

describe('MainspringComponent', () => {
  let component: MainspringComponent;
  let fixture: ComponentFixture<MainspringComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainspringComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainspringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
