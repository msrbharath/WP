import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { SummaryComponent } from './summary/summary.component';
import { OperationalComponent } from './operational/operational.component';
import { DeliveryComponent } from './delivery/delivery.component';
import { ProjectsComponent } from './projects/projects.component';
import { ChangesComponent } from './changes/changes.component';
import { AwardsComponent } from './awards/awards.component';
import { CertificationComponent } from './certification/certification.component';
import { InnovationComponent } from './innovation/innovation.component';
import { MainspringComponent } from './mainspring/mainspring.component';
import { ProposalComponent } from './proposal/proposal.component';
import { ExcelComponent } from './excel/excel.component';

@NgModule({
  declarations: [
    AppComponent,
    SummaryComponent,
    OperationalComponent,
    DeliveryComponent,
    ProjectsComponent,
    ChangesComponent,
    AwardsComponent,
    CertificationComponent,
    InnovationComponent,
    MainspringComponent,
    ProposalComponent,
    ExcelComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
