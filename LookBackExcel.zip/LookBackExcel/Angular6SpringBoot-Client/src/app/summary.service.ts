import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SummaryService {

  private baseUrl = 'http://localhost:8080/api/summary';

  constructor(private http: HttpClient) { }

  getSummary(id: number): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createSummary(summary: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}` + `/create`, summary);
  }

  updateSummary(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteSummary(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getSummaryList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }

  getSummaryByCategory(summary: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/category/${summary}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(`${this.baseUrl}` + `/delete`, { responseType: 'text' });
  }
}
